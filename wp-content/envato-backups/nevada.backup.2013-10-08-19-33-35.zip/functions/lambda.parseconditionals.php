<?php
#-----------------------------------------------------------------
# Fallback function
#----------------------------------------------------------------- 

if ( ! function_exists( 'is_shop()' ) ) :
	function is_shop() {
	
		return FALSE;
		
	}
endif;

if ( ! function_exists( 'is_product()' ) ) :
	function is_product() {
	
		return FALSE;
		
	}
endif;

?>