<ul class="right" style="margin-bottom:14px; margin-top:20px;">                  
	<li><a href="<?php echo home_url(); ?>/wp-admin/nav-menus.php"><?php _e('Set Up Your Menu', UT_THEME_NAME); ?></a></li>
</ul>